<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="footer.css">
</head>
<body style="background-color: #0D1B2A">
<footer class="footer" style="display: block;">
    <div class="footer-container">
        <div class="follow-us-on">
            <h2>FOLLOW US ON</h2>
            <p>See Social Media<p>                    
        </div>
        <hr>
        <div class="footer-links">
            <div class="footer-legal">
                <a class="footer-legal-link" href="#">FAQ</a>
                <a class="footer-legal-link" href="#">Privacy Notice</a>
                <a class="footer-legal-link" href="#">Cookie Notice</a>
                <a class="admin" href="#">Admin</a>
            </div>
        </div>
    </div>
</footer>
</body>
</html>